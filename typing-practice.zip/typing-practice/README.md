# Typing Practice

A Pen created on CodePen.io. Original URL: [https://codepen.io/Nalini1998/pen/VwVJXmg/37648ca2fe844fd4ca70f757b3c33d10](https://codepen.io/Nalini1998/pen/VwVJXmg/37648ca2fe844fd4ca70f757b3c33d10).

# Typing Practice App
This app allows users to practice their typing skills by randomly targeting keys on the keyboard and measuring their typing speed.

## Installation
To use this app, simply download the code and open the index.html file in your browser.

## Usage
Once the app is open in your browser, start typing when a key is highlighted in yellow. If you successfully type the correct key, your typing speed (in characters per minute) will be displayed in the console. The app will continue to randomly target keys for you to type.

## Credits
This app was created by Meow.Nalini98. It makes use of the FontAwesome paw icon, available at https://fontawesome.com/icons/paw.

## License
This code is available under the MIT License.